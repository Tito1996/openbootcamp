class Suma {
    
    public static void main(String[] args) {
        int resultado = suma(23, 3, 12);
        System.out.println(resultado);
    }

    public static int suma(int a, int b, int c){
        return a + b + c;
    }
}